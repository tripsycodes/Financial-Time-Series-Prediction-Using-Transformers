# streamlit_app.py
import streamlit as st
import numpy as np, pandas as pd, joblib, json
import torch, torch.nn as nn
from sklearn.linear_model import Ridge
import matplotlib.pyplot as plt

# ---------------------------
# Configuration (match training)
# ---------------------------
SEQ_LEN =  30  # <- must match what you trained with (replace or keep if global)
H = 5
DEVICE = "cpu"

# ---------------------------
# Helper: Transformer architecture matching training (mean pooling)
# ---------------------------
import math
class PositionalEncoding(nn.Module):
    def __init__(self, d_model, max_len=1000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        pos = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0)/d_model))
        pe[:, 0::2] = torch.sin(pos * div)
        pe[:, 1::2] = torch.cos(pos * div)
        self.register_buffer('pe', pe.unsqueeze(0))
    def forward(self, x): return x + self.pe[:, :x.size(1), :]

class MarketTransformer(nn.Module):
    def __init__(self, channels, seq_len, num_tickers, d_model=256, nhead=8, num_layers=6, dim_ff=512, dropout=0.1, pool='mean'):
        super().__init__()
        self.pool = pool
        self.inp = nn.Linear(channels, d_model)
        self.pos = PositionalEncoding(d_model, seq_len)
        layer = nn.TransformerEncoderLayer(d_model, nhead, dim_ff, dropout, batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(layer, num_layers)
        self.head = nn.Sequential(nn.LayerNorm(d_model), nn.Linear(d_model, num_tickers))
    def forward(self, x):
        h = self.inp(x)
        h = self.pos(h)
        h = self.enc(h)
        h = h.mean(dim=1) if self.pool=='mean' else h[:, -1, :]
        return self.head(h)

# ---------------------------
# Load artifacts (must exist)
# ---------------------------
@st.cache_resource
def load_artifacts():
    scaler_X = joblib.load("scaler_X.pkl")                   # StandardScaler fitted on flattened windows
    target_scalers = joblib.load("target_scalers.pkl")       # dict {ticker: StandardScaler for y}
    ridge_models = joblib.load("ridge_models.pkl")           # list of Ridge models per ticker
    ensemble_w = np.load("ensemble_weights.npy")             # (num_tickers,)
    state = torch.load("market_transformer.pth", map_location="cpu")
    with open("tickers.json","r") as f: tickers = json.load(f)
    with open("enh_feats.json","r") as f: enh_feats = json.load(f)
    return scaler_X, target_scalers, ridge_models, ensemble_w, state, tickers, enh_feats

try:
    scaler_X, target_scalers, ridge_models, ensemble_w, state_dict, TICKERS, ENH_FEATS = load_artifacts()
except Exception as e:
    st.error("Failed to load model artifacts. Make sure the following files exist next to app.py:\n"
             "scaler_X.pkl, target_scalers.pkl, ridge_models.pkl, ensemble_weights.npy, market_transformer.pth, tickers.json, enh_feats.json\n\nError:\n" + str(e))
    st.stop()

NUM_TICKERS = len(TICKERS)
NUM_FEATS = len(ENH_FEATS)
C = NUM_TICKERS * NUM_FEATS

# build transformer and load state
model = MarketTransformer(C, SEQ_LEN, NUM_TICKERS)
model.load_state_dict(state_dict)
model.to(DEVICE).eval()

# ---------------------------
# Feature engineering (same as training) - works when you have a full X_panel
# ---------------------------
def build_enhanced_features(X_panel, tickers, base_feats):
    X = X_panel.copy()
    dates = X.index
    close_ret = X.loc[:, pd.IndexSlice[:, 'Close_ret']]
    close_ret.columns = [c[0] for c in close_ret.columns]
    vol_raw = X.loc[:, pd.IndexSlice[:, 'Vol']]
    vol_raw.columns = [c[0] for c in vol_raw.columns]
    mkt_r1 = close_ret.mean(axis=1)
    mkt_mom_5 = mkt_r1.rolling(5).mean()
    new_blocks = {}
    for tk in tickers:
        r = close_ret[tk]
        v = vol_raw[tk]
        mom_5  = r.rolling(5).sum()
        mom_10 = r.rolling(10).sum()
        vol_10 = r.rolling(10).std()
        vol_20 = r.rolling(20).std()
        z_5    = (r - r.rolling(5).mean()) / (r.rolling(5).std() + 1e-12)
        log_vol = np.log1p(v.clip(lower=0))
        vol_z20 = (v - v.rolling(20).mean()) / (v.rolling(20).std() + 1e-12)
        blk = pd.DataFrame({
            'Open_ret'  : X[(tk, 'Open_ret')],
            'High_ret'  : X[(tk, 'High_ret')],
            'Low_ret'   : X[(tk, 'Low_ret')],
            'Close_ret' : r,
            'Vol'       : v,
            'mom_5'     : mom_5,
            'mom_10'    : mom_10,
            'vol_10'    : vol_10,
            'vol_20'    : vol_20,
            'z_5'       : z_5,
            'log_vol'   : log_vol,
            'vol_z20'   : vol_z20,
            'mkt_r1'    : mkt_r1,
            'mkt_mom_5' : mkt_mom_5
        }, index=dates)
        new_blocks[tk] = blk
    pieces = []
    for tk in tickers:
        df = new_blocks[tk]
        df.columns = pd.MultiIndex.from_product([[tk], df.columns])
        pieces.append(df)
    X_enh = pd.concat(pieces, axis=1).sort_index(axis=1)
    return X_enh

# ---------------------------
# Window builder (same as training)
# ---------------------------
def make_windows_from_enh(X_enh, Close_panel, seq_len, tickers):
    # aligns and drops nan rows exactly like training
    close_ret = X_enh.loc[:, pd.IndexSlice[:, 'Close_ret']]
    # y_all is H-day return using Close_panel
    y_all = (Close_panel.shift(-H) / Close_panel) - 1.0
    X_clean = X_enh.dropna()
    y_clean = y_all.loc[X_clean.index]
    valid_idx = y_clean.index[:-H] if y_clean.iloc[-H:].isna().values.any() else y_clean.index
    X_clean = X_clean.loc[valid_idx]
    y_clean = y_clean.loc[valid_idx]
    dates = X_clean.index
    L = seq_len
    cols = []
    for tk in tickers:
        for f in ENH_FEATS:
            cols.append((tk,f))
    X_list, y_list, end_dates = [], [], []
    for i in range(L-1, len(dates)):
        start = i - (L-1)
        win_X = X_clean.iloc[start:i+1]
        win_mat = win_X.loc[:, cols].values
        X_list.append(win_mat)
        y_vec = y_clean.loc[dates[i], tickers].values
        y_list.append(y_vec)
        end_dates.append(dates[i])
    return np.array(X_list, dtype=np.float32), np.array(y_list, dtype=np.float64), np.array(end_dates)

# ---------------------------
# Utility: inverse standardized returns per ticker
# ---------------------------
def inverse_returns(std_returns):
    out = np.zeros_like(std_returns, dtype=np.float64)
    for j, tk in enumerate(TICKERS):
        sc = target_scalers[tk]
        out[:, j] = sc.inverse_transform(std_returns[:, [j]]).reshape(-1)
    return out

# ---------------------------
# UI: Top-level
# ---------------------------
st.set_page_config(layout="wide", page_title="Market Transformer Ensemble")
st.title("MarketTransformer Ensemble — Streamlit")
st.markdown("Upload recent `X_panel` (same format as training) for accurate multi-ticker predictions, or use the quick single-ticker mode (approximate).")

mode = st.radio("Mode", ["Full-panel upload (recommended)", "Quick single-ticker (approximate)"])

if mode == "Full-panel upload (recommended)":
    st.markdown("**Upload CSV of X_panel**: date index, MultiIndex columns (Ticker, Feature) flattened as `Ticker|Feature` or preserved MultiIndex when saved with pandas.")
    uploaded = st.file_uploader("Upload CSV (X_panel)", type=["csv"])
    close_upload = st.file_uploader("Optional: Close_t_panel CSV (if you want to override)", type=["csv"])
    if uploaded is not None:
        # read CSV — try to detect multiindex columns encoded as 'Ticker|Feature'
        df_raw = pd.read_csv(uploaded, index_col=0, parse_dates=True)
        # if columns contain '|' split into MultiIndex
        if any("|" in c for c in df_raw.columns):
            cols = [tuple(c.split("|")) for c in df_raw.columns]
            df_raw.columns = pd.MultiIndex.from_tuples(cols)
        # else, if multiindex serialized differently, hope user saved properly
        X_panel_user = df_raw.copy()
        if close_upload is not None:
            Close_panel = pd.read_csv(close_upload, index_col=0, parse_dates=True)
            # ensure columns are tickers
        else:
            st.info("Will try to use Close prices inside uploaded panel (must include (Ticker, 'Close') or use training Close_t_panel file).")
            # try to extract Close from X_panel_user
            try:
                Close_panel = pd.concat([X_panel_user.loc[:, (tk, 'Close')] for tk in TICKERS], axis=1)
                Close_panel.columns = TICKERS
            except Exception:
                st.warning("Could not infer Close panel from the uploaded file. Please upload Close_t_panel separately.")
                Close_panel = None

        try:
            X_enh = build_enhanced_features(X_panel_user, TICKERS, None)
        except Exception as e:
            st.error("Feature construction failed. Ensure uploaded X_panel contains base features for each ticker: Open_ret,High_ret,Low_ret,Close_ret,Vol\nError: "+str(e))
            st.stop()

        if Close_panel is None:
            st.error("Close panel unavailable. Provide Close_t_panel CSV or include Close in X_panel.")
            st.stop()

        # Build windows
        X_w, y_w, dates_w = make_windows_from_enh(X_enh, Close_panel, SEQ_LEN, TICKERS)
        st.write(f"Built {len(X_w)} windows; using the most recent window for prediction.")
        if len(X_w) == 0:
            st.error("Not enough data to build one window (need at least SEQ_LEN + H rows).")
            st.stop()

        # scale: use scaler_X (which expects flattened windows)
        C_local = X_w.shape[-1]
        flat = X_w.reshape(-1, C_local)
        flat_scaled = scaler_X.transform(flat)
        X_scaled = flat_scaled.reshape(X_w.shape)

        # take last window
        X_input = X_scaled[-1:]
        # run transformer -> standardized returns
        with torch.no_grad():
            y_std_tf = model(torch.tensor(X_input).to(DEVICE)).cpu().numpy()      # (1, T)
        y_tf_raw = inverse_returns(y_std_tf)   # raw returns (1, T)

        # Ridge preds: use last-day features original (unscaled) or scaled as training (training used scaled last-day window)
        # We will feed ridge the scaled last-step features (matching training)
        last_step = X_scaled[-1, -1, :]   # (C,)
        # split per ticker features
        y_rg = np.zeros(NUM_TICKERS)
        F = NUM_FEATS
        for j in range(NUM_TICKERS):
            s, e = j*F, (j+1)*F
            X_last = last_step[s:e].reshape(1, -1)
            y_rg[j] = ridge_models[j].predict(X_last)[0]

        # blend
        y_pred = ensemble_w * y_tf_raw.flatten() + (1-ensemble_w) * y_rg.flatten()
        # last close for this end-date (we can take Close_panel.loc[dates_w[-1]])
        if dates_w is not None:
            last_close_row = Close_panel.loc[dates_w[-1], TICKERS].values
        else:
            last_close_row = np.ones(NUM_TICKERS) * 100.0
        price_pred = last_close_row * (1 + y_pred)

        df_out = pd.DataFrame({
            'Ticker': TICKERS,
            'Pred_Return': y_pred,
            'Pred_Price': price_pred,
            'TF_Return': y_tf_raw.flatten(),
            'Ridge_Return': y_rg,
            'Blend_w': ensemble_w
        }).set_index('Ticker')
        st.subheader("Predictions (most recent window)")
        st.dataframe(df_out)

        # visualize top tickers by predicted return
        fig, ax = plt.subplots(figsize=(8,3))
        df_out['Pred_Return'].sort_values().plot(kind='barh', ax=ax, title='Predicted H-day returns (sorted)')
        st.pyplot(fig)

        # show per-ticker inverse scaling / explainability
        st.write("Transformer (raw) vs Ridge vs blended (per ticker).")
else:
    # Quick single ticker mode (approximate)
    st.info("Approximate single-ticker mode: enter SEQ_LEN rows of base features for one ticker. Market factors are approximated from this ticker only.")
    sel_ticker = st.selectbox("Ticker", TICKERS)
    st.markdown(f"Enter last {SEQ_LEN} timesteps of base features for {sel_ticker}: (Open_ret,High_ret,Low_ret,Close_ret,Vol)")
    rows = []
    for t in range(SEQ_LEN):
        cols = st.columns(5)
        r = []
        for i,col in enumerate(cols):
            val = col.number_input(f"T-{SEQ_LEN-t} feature {i+1}", value=0.0, key=f"{sel_ticker}_{t}_{i}")
            r.append(val)
        rows.append(r)
    last_close = st.number_input("Last close price", value=100.0, key="lc_quick")
    if st.button("Predict (quick)"):
        base_cols = ['Open_ret','High_ret','Low_ret','Close_ret','Vol']
        # build per-ticker df for these rows
        idx = pd.date_range(end=pd.Timestamp.today(), periods=SEQ_LEN, freq='D')
        df_tk = pd.DataFrame(rows, index=idx, columns=base_cols)
        # compute engineered features for this ticker only (market factors approximated)
        r = df_tk['Close_ret']
        v = df_tk['Vol']
        mom_5  = r.rolling(5).sum()
        mom_10 = r.rolling(10).sum()
        vol_10 = r.rolling(10).std()
        vol_20 = r.rolling(20).std()
        z_5    = (r - r.rolling(5).mean()) / (r.rolling(5).std()+1e-12)
        log_vol = np.log1p(v.clip(lower=0))
        vol_z20 = (v - v.rolling(20).mean()) / (v.rolling(20).std()+1e-12)
        mkt_r1 = r  # approx
        mkt_mom_5 = mkt_r1.rolling(5).mean()
        df_enh = pd.DataFrame({
            'Open_ret': df_tk['Open_ret'],
            'High_ret': df_tk['High_ret'],
            'Low_ret': df_tk['Low_ret'],
            'Close_ret': df_tk['Close_ret'],
            'Vol': df_tk['Vol'],
            'mom_5': mom_5, 'mom_10': mom_10, 'vol_10': vol_10, 'vol_20': vol_20,
            'z_5': z_5, 'log_vol': log_vol, 'vol_z20': vol_z20,
            'mkt_r1': mkt_r1, 'mkt_mom_5': mkt_mom_5
        }, index=idx).fillna(0.0)
        # flatten to (L, C_ticker) then build a full-sized C vector by placing this ticker block at its position
        cols_order = ENH_FEATS
        X_block = df_enh[cols_order].values  # (L, F)
        # build full C vector where other tickers are zeros
        C = NUM_TICKERS * NUM_FEATS
        X_full_window = np.zeros((SEQ_LEN, C), dtype=np.float32)
        tk_idx = TICKERS.index(sel_ticker)
        s,e = tk_idx*NUM_FEATS, (tk_idx+1)*NUM_FEATS
        X_full_window[:, s:e] = X_block
        # scale using scaler_X (transform expects flattened windows)
        X_flat = X_full_window.reshape(-1, C)
        try:
            X_flat_scaled = scaler_X.transform(X_flat)
        except Exception as e:
            st.error("Scaler transform failed: make sure scaler_X.pkl matches feature order. Error: "+str(e))
            st.stop()
        X_scaled = X_flat_scaled.reshape(1, SEQ_LEN, C)
        # transformer predict (std returns) -> inverse
        with torch.no_grad():
            y_std_tf = model(torch.tensor(X_scaled).to(DEVICE)).cpu().numpy()
        y_tf_raw = inverse_returns(y_std_tf).flatten()
        # ridge prediction on last-step features (use scaled last-step)
        last_step = X_scaled[0, -1, s:e].reshape(1, -1)
        y_rg = ridge_models[tk_idx].predict(last_step)[0]
        y_pred = ensemble_w[tk_idx] * y_tf_raw[tk_idx] + (1-ensemble_w[tk_idx]) * y_rg
        price_pred = last_close * (1 + y_pred)
        st.write(f"Predicted {H}-day return (blended) for {sel_ticker}: {y_pred:.6f}")
        st.write(f"Predicted {H}-day price: {price_pred:.4f}")
        st.write(f"Transformer raw return (per ticker block): {y_tf_raw[tk_idx]:.6f}")
        st.write(f"Ridge raw return: {y_rg:.6f}")
